import React, { useState } from 'react';
import DatePicker from 'react-multi-date-picker';
import persian from 'react-date-object/calendars/persian';
import persian_fa from 'react-date-object/locales/persian_fa';
import api from 'api/api';
import jalaali from 'jalaali-js';

const CalorieTrackingSection = () => {
  const [userId, setUserId] = useState(() => {
    // try to get from localStorage or generate new
    let user = localStorage.getItem('userData');
    if (user) {
      try {
        user = JSON.parse(user);
        if (user && user.id) {
          return user.id;
        }
      } catch (e) {
        console.error('Error parsing userData from localStorage', e);
      }
    }
  });

  const toGregorian = (dateObject) => {
    if (!dateObject) return null;

    // dateObject به صورت DateObject از react-multi-date-picker است
    const shamsi = dateObject.format('YYYY-MM-DD'); // رشته شمسی
    const [jy, jm, jd] = shamsi.split('-').map(Number);
    const { gy, gm, gd } = jalaali.toGregorian(jy, jm, jd);
    return `${gy}-${String(gm).padStart(2, '0')}-${String(gd).padStart(
      2,
      '0'
    )}`;
  };
  const [fields, setFields] = useState({
    userId: userId,
    periodType: 'weekly',
    periodStart: null,
    periodEnd: null,
    avgCalories: '',
    proteinPercent: '',
    carbsPercent: '',
    fatsPercent: '',
    avgSteps: '',
    strengthDays: '',
    note: '',
  });

  const handleChange = (name, value) => {
    setFields((prev) => ({ ...prev, [name]: value }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const payload = {
        userId: fields.userId,
        periodType: fields.periodType,
        periodStart: toGregorian(fields.periodStart),
        periodEnd: toGregorian(fields.periodEnd),
        avgCalories: Number(fields.avgCalories),
        proteinPercent: Number(fields.proteinPercent),
        carbsPercent: Number(fields.carbsPercent),
        fatsPercent: Number(fields.fatsPercent),
        avgSteps: Number(fields.avgSteps),
        strengthDays: Number(fields.strengthDays),
        note: fields.note,
      };
      console.log('Submitting payload:', payload);
      await api.post('/report', payload);
      alert('گزارش با موفقیت ارسال شد');
    } catch (err) {
      console.error(err);
      alert('ارسال گزارش با مشکل مواجه شد');
    }
  };

  return (
    <form onSubmit={handleSubmit} className="flex flex-col gap-4 p-3">
      <label>دوره گزارش — شروع (جلالی)</label>
      <DatePicker
        calendar={persian}
        locale={persian_fa}
        value={fields.periodStart}
        onChange={(v) => handleChange('periodStart', v)}
        format="YYYY-MM-DD"
        className="border"
      />

      <label>دوره گزارش — پایان (جلالی)</label>
      <DatePicker
        calendar={persian}
        locale={persian_fa}
        value={fields.periodEnd}
        onChange={(v) => handleChange('periodEnd', v)}
        format="YYYY-MM-DD"
        className="border"
      />

      <label>کالری میانگین</label>
      <input
        type="number"
        value={fields.avgCalories}
        onChange={(e) => handleChange('avgCalories', e.target.value)}
        className="border p-2 rounded"
        required
      />

      <label>درصد پروتئین</label>
      <input
        type="number"
        value={fields.proteinPercent}
        onChange={(e) => handleChange('proteinPercent', e.target.value)}
        className="border p-2 rounded"
        required
      />

      <label>درصد کربوهیدرات</label>
      <input
        type="number"
        value={fields.carbsPercent}
        onChange={(e) => handleChange('carbsPercent', e.target.value)}
        className="border p-2 rounded"
        required
      />

      <label>درصد چربی</label>
      <input
        type="number"
        value={fields.fatsPercent}
        onChange={(e) => handleChange('fatsPercent', e.target.value)}
        className="border p-2 rounded"
        required
      />

      <label>میانگین قدم‌ها</label>
      <input
        type="number"
        value={fields.avgSteps}
        onChange={(e) => handleChange('avgSteps', e.target.value)}
        className="border p-2 rounded"
        required
      />

      <label>تعداد روزهای تمرین قدرتی</label>
      <input
        type="number"
        value={fields.strengthDays}
        onChange={(e) => handleChange('strengthDays', e.target.value)}
        className="border p-2 rounded"
        required
      />

      <label>یادداشت</label>
      <textarea
        value={fields.note}
        onChange={(e) => handleChange('note', e.target.value)}
        className="border p-2 rounded"
      />

      <button type="submit" className="bg-blue-600 text-white p-2 rounded">
        ثبت گزارش
      </button>
    </form>
  );
};

export default CalorieTrackingSection;
